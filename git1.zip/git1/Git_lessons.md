
#Шпора по git

Команда смены директории
```sh
cd c: folder_name/.../.../
```

Комана отображения текущей директории(mac_os, linux)
``` sh
pwd
```

Листинг текущей директории
Windows:
``` sh
dir
```

Удаление файла
Windows:
``` sh
del <file_name>
```